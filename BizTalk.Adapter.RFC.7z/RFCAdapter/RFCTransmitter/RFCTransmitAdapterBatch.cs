using System;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.BizTalk.TransportProxy.Interop;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.Samples.BizTalk.Adapter.Common;
namespace Microsoft.Samples.BizTalk.Adapters.RFCTransmitter
{
	public class RFCTransmitAdapterBatch : AsyncTransmitterBatch
	{
		public RFCTransmitAdapterBatch(int maxBatchSize, string propertyNamespace, IBTTransportProxy transportProxy, 
                    AsyncTransmitter asyncTransmitter) :
			   base(maxBatchSize, typeof(RFCTransmitterEndpoint), propertyNamespace, null, transportProxy, asyncTransmitter)
		{
		}
	}
}
