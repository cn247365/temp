using System;
using System.Runtime.Serialization;
using Microsoft.Samples.BizTalk.Adapter.Common;
namespace Microsoft.Samples.BizTalk.Adapters.RFCTransmitter
{
	internal class RFCAdapterException : ApplicationException
	{
		public static string UnhandledTransmit_Error = "The .Net File Adapter encounted an error transmitting a batch of messages.";
		public RFCAdapterException () { }
		public RFCAdapterException (string msg) : base(msg) { }
		public RFCAdapterException (Exception inner) : base(String.Empty, inner) { }
		public RFCAdapterException (string msg, Exception e) : base(msg, e) { }
		protected RFCAdapterException (SerializationInfo info, StreamingContext context) : base(info, context) { }
	}
}
