using System;
using System.Xml;
using System.Threading;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.TransportProxy.Interop;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.Samples.BizTalk.Adapter.Common;
namespace Microsoft.Samples.BizTalk.Adapters.RFCTransmitter
{
    sealed public class RFCTransmitAdapter : AsyncTransmitter
    {
        private static string httpNamespace = "http://schemas.microsoft.com/BizTalk/2003/SDK_Samples/Messaging/Transports/dotnethttp-properties";
        public RFCTransmitAdapter() : base(
                ".Net RFC Transmit Adapter",
                "1.0",
                ".NET RFC Transmit Adapter SDK Sample",
                "RFC.NET",
                new Guid("D5353BB1-BAE9-4de7-8362-F1160FAD3985"),
                httpNamespace, typeof(RFCTransmitterEndpoint), 30)
        {
        }
        protected override IBTTransmitterBatch CreateAsyncTransmitterBatch()
        {
            return new RFCTransmitAdapterBatch(30, httpNamespace, TransportProxy, this);
        }
        public ConfigProperties CreateProperties(string uri)
        {
            ConfigProperties properties = new RFCAdapterProperties(uri);
            return properties;
        }
        protected override void HandlerPropertyBagLoaded ()
        {
            IPropertyBag config = this.HandlerPropertyBag;
            if (null != config)
            {
                XmlDocument handlerConfigDom = ConfigProperties.IfExistsExtractConfigDom(config);
                if (null != handlerConfigDom)
                {
                    RFCAdapterProperties.TransmitHandlerConfiguration(handlerConfigDom);
                }
            }
        }
    }
}
