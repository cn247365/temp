using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Net;
using System.Collections;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Microsoft.BizTalk.Streaming;
using Microsoft.BizTalk.TransportProxy.Interop;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.Samples.BizTalk.Adapter.Common;
using Microsoft.XLANGs.BaseTypes;
using SAP.Middleware.Connector;
using BizTalk.Adapter.RFC.Core;
using System.Data.SqlClient;
using System.Linq;
namespace Microsoft.Samples.BizTalk.Adapters.RFCTransmitter
{
    internal class RFCTransmitterEndpoint: AsyncTransmitterEndpoint
    {
        private IBaseMessage    solicitMsg                    = null;
        private IBTTransportProxy    transportProxy                = null;
        private AsyncTransmitter    asyncTransmitter            = null;
        private string propertyNamespace;
        private static int IO_BUFFER_SIZE = 8192;
        public RFCTransmitterEndpoint(AsyncTransmitter asyncTransmitter) : base(asyncTransmitter)
        {
            this.asyncTransmitter = asyncTransmitter;
            this.transportProxy = asyncTransmitter.TransportProxy;
        }
        public override void Open(EndpointParameters endpointParameters, IPropertyBag handlerPropertyBag, string propertyNamespace)
        {
            this.propertyNamespace = propertyNamespace;
        }
        public override IBaseMessage ProcessMessage(IBaseMessage message)
        {
            RFCAdapterProperties props = new RFCAdapterProperties(message, this.propertyNamespace);
            var outputmessagetype = string.Empty;
            if ( props.IsTwoWay )
            {
                var response = SendRFCRequest(message, props, out outputmessagetype);
                solicitMsg = BuildResponseMessage(response, outputmessagetype);
            }
            else
            {
                var response = SendRFCRequest(message, props, out outputmessagetype);
                response.Close();
            }
            return solicitMsg;
        }
        private IBaseMessage BuildResponseMessage(Stream reponse,string messagetype)
        {
            IBaseMessage btsResponse = null;
            using (Stream s = reponse)
            {
                reponse.Seek(0, SeekOrigin.Begin);
                VirtualStream vs = new VirtualStream();
                int bytesRead = 0;
                byte[] buff = new byte[IO_BUFFER_SIZE];
                while ((bytesRead = s.Read(buff, 0, buff.Length)) > 0)
                    vs.Write(buff, 0, bytesRead);
                reponse.Close();
                vs.Position = 0;
                IBaseMessageFactory mf = transportProxy.GetMessageFactory();
                btsResponse = mf.CreateMessage();
                btsResponse.Context.Write("MessageType", "http://schemas.microsoft.com/BizTalk/2003/system-properties", messagetype);
                btsResponse.Context.Promote("MessageType", "http://schemas.microsoft.com/BizTalk/2003/system-properties", messagetype);
                IBaseMessagePart body = mf.CreateMessagePart();
                body.Data = vs;
                btsResponse.AddPart("Body", body, true);
            }
            return btsResponse;
        }
        private Stream SendRFCRequest(IBaseMessage msg, RFCAdapterProperties config,out string outputmessagetype)
        {
            #region SSO Usage Example
            /*
            string ssoAffiliateApplication = props.AffiliateApplication;
            if (ssoAffiliateApplication.Length > 0)
            {
                SSOResult ssoResult = new SSOResult(msg, affiliateApplication);
                string userName  = ssoResult.UserName;
                string password  = ssoResult.Result[0];
                string etcEtcEtc = ssoResult.Result[1]; // (you can have additional metadata associated with the login in SSO) 
            }                    
            */
            #endregion // SSO Usage Example
            var rfc = new RfcConfigParameters();
            rfc.Add(RfcConfigParameters.Name, config.DestinationName);
            rfc.Add(RfcConfigParameters.AppServerHost, config.AppServerHost);
            rfc.Add(RfcConfigParameters.Client, config.Client);
            rfc.Add(RfcConfigParameters.User, config.User);
            rfc.Add(RfcConfigParameters.Password, config.Password);
            rfc.Add(RfcConfigParameters.SystemNumber, config.SystemNumber);
            rfc.Add(RfcConfigParameters.Language, config.Language);
            rfc.Add(RfcConfigParameters.PoolSize, config.PoolSize);
            rfc.Add(RfcConfigParameters.IdleCheckTime, "30");
            rfc.Add(RfcConfigParameters.PeakConnectionsLimit, config.PeakConnectionsLimit);
            rfc.Add(RfcConfigParameters.ConnectionIdleTimeout, config.ConnectionIdleTimeout);
            var dest = RfcDestinationManager.GetDestination(rfc);
            var selector = new AssemblySelector(config.RequestSchemaType);
            var doc = new XmlDocument();
            using (XmlReader reader = XmlReader.Create(msg.BodyPart.Data))
            {
                doc.Load(reader);
            }
            var dis = new MessageDisassembly(selector, dest);
            var fun = dis.Disassemble(doc);
            var inputmsgtype = dis.GetMessageType();
            msg.Context.Write("MessageType", "http://schemas.microsoft.com/BizTalk/2003/system-properties", inputmsgtype);
            msg.Context.Promote("MessageType", "http://schemas.microsoft.com/BizTalk/2003/system-properties", inputmsgtype);
            var outputselector = new AssemblySelector(config.ReponseSchemaType);
            var gen = new MessageGenerator(outputselector, fun);
            var stream = gen.CreateInstance();
            outputmessagetype = gen.GetMessageType();
            stream.Position = 0;
            return stream;
        }
    }
}
