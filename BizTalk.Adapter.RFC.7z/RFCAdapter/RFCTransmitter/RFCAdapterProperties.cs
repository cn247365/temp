using System;
using System.IO;
using System.Xml;
using System.Net;
using Microsoft.XLANGs.BaseTypes;
using Microsoft.BizTalk.Message.Interop;
using Microsoft.Samples.BizTalk.Adapter.Common;
namespace Microsoft.Samples.BizTalk.Adapters.RFCTransmitter
{
    public class RFCAdapterProperties : ConfigProperties
    {
        private static string protocolAlias = "RFC.NET://";
        private static int                handlerTimeout    = 120000;
        private string appServerHost;
        private string destinationName;
        private string client;
        private string systemNumber;
        private string language;
        private string user;
        private string password;
        private string poolSize;
        private string peakConnectionsLimit;
        private string connectionIdleTimeout;
        private string programId;
        private string schemaAssembly;
        private string requestSchemaType;
        private string reponseSchemaType;
        private string uri;
        public string Uri { get { return uri; } }
        private static PropertyBase isSolicitResponseProp = new BTS.IsSolicitResponse();
        private bool _isTwoWay;
        public bool IsTwoWay { get { return _isTwoWay; } }
        public string AppServerHost
        {
            get
            {
                return appServerHost;
            }
        }
        public string DestinationName
        {
            get
            {
                return destinationName;
            }
        }
        public string Client
        {
            get
            {
                return client;
            }
        }
        public string SystemNumber
        {
            get
            {
                return systemNumber;
            }
        }
        public string Language
        {
            get
            {
                return language;
            }
        }
        public string User
        {
            get
            {
                return user;
            }
        }
        public string Password
        {
            get
            {
                return password;
            }
        }
        public string PoolSize
        {
            get
            {
                return poolSize;
            }
        }
        public string PeakConnectionsLimit
        {
            get
            {
                return peakConnectionsLimit;
            }
        }
        public string ConnectionIdleTimeout
        {
            get
            {
                return connectionIdleTimeout;
            }
        }
        public string SchemaAssembly
        {
            get
            {
                return schemaAssembly;
            }
        }
        public string RequestSchemaType
        {
            get
            {
                return requestSchemaType;
            }
        }
        public string ReponseSchemaType
        {
            get
            {
                return reponseSchemaType;
            }
        }
        public string ProgramId
        {
            get
            {
                return programId;
            }
        }
        public RFCAdapterProperties(IBaseMessage message, string propertyNamespace)
        {
            XmlDocument locationConfigDom = null;
            string config = (string) message.Context.Read("AdapterConfig", propertyNamespace);
            this._isTwoWay = (bool) message.Context.Read(isSolicitResponseProp.Name.Name, isSolicitResponseProp.Name.Namespace);
            if (null != config)
            {
                locationConfigDom = new XmlDocument();
                locationConfigDom.LoadXml(config);
                this.LocationConfiguration(locationConfigDom);
            }
        }
        public RFCAdapterProperties(string uri)
        {
            this.uri = uri;
            UpdateUriForDynamicSend();
        }
        public static void TransmitHandlerConfiguration (XmlDocument configDOM)
        {
            RFCAdapterProperties.handlerTimeout = ExtractInt(configDOM, "/Config/timeout");
        }
        public void LocationConfiguration(XmlDocument configDOM)
        {
            this.uri = Extract(configDOM, "Config/uri", null);
            this.appServerHost = IfExistsExtract(configDOM, "/Config/appServerHost", "");
            this.destinationName = IfExistsExtract(configDOM, "/Config/destinationName", "DTM");
            this.client = IfExistsExtract(configDOM, "/Config/client", "212");
            this.systemNumber = IfExistsExtract(configDOM, "/Config/systemNumber", "00");
            this.language= IfExistsExtract(configDOM, "/Config/language", "ZH");
            this.user= IfExistsExtract(configDOM, "/Config/user", "soapcall");
            this.password = IfExistsExtract(configDOM, "/Config/password", "soapcall") ;
            this.poolSize= IfExistsExtract(configDOM, "/Config/poolSize", "5");
            this.peakConnectionsLimit= IfExistsExtract(configDOM, "/Config/peakConnectionsLimit", "10");
            this.connectionIdleTimeout= IfExistsExtract(configDOM, "/Config/connectionIdleTimeout", "500");
            this.schemaAssembly = IfExistsExtract(configDOM, "/Config/schemaAssembly", "");
            this.requestSchemaType = IfExistsExtract(configDOM, "/Config/requestSchemaType", "");
            this.reponseSchemaType = IfExistsExtract(configDOM, "/Config/reponseSchemaType", "");
            this.programId = IfExistsExtract(configDOM, "/Config/programId", "");
        }
        public void UpdateUriForDynamicSend()
        {
            if ( this.uri.StartsWith(protocolAlias, StringComparison.OrdinalIgnoreCase))
            {
                string newUri = this.uri.Substring(protocolAlias.Length);
                this.uri = newUri;
            }
        }
    }
}
