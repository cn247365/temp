using System;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using Microsoft.Win32;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.Adapter.Framework;
namespace Microsoft.Samples.BizTalk.Adapters.Designtime
{
    public class RFCAdapter : IAdapterConfig, IStaticAdapterConfig, IAdapterConfigValidation 
	{
		private static ResourceManager resourceManager = new ResourceManager("AdapterManagement.RFCAdapterResource", Assembly.GetExecutingAssembly());
		protected string LocalizeSchema (string schema, ResourceManager resourceManager)
		{
			XmlDocument document = new XmlDocument();
			document.LoadXml(schema);
			XmlNodeList nodes = document.SelectNodes("/descendant::*[@_locID]");
			foreach (XmlNode node in nodes)
			{
				string locID = node.Attributes["_locID"].Value;
				node.InnerText = resourceManager.GetString(locID);
			}
			StringWriter writer = new StringWriter();
			document.WriteTo(new XmlTextWriter(writer));
			string localizedSchema = writer.ToString();
			return localizedSchema;
		}
        public string GetConfigSchema(ConfigType type) 
		{
            switch (type) 
			{
				case ConfigType.ReceiveHandler:
					return LocalizeSchema(GetResource("AdapterManagement.ReceiveHandler.xsd"), resourceManager);
				case ConfigType.ReceiveLocation:
					return LocalizeSchema(GetResource("AdapterManagement.ReceiveLocation.xsd"), resourceManager);
				case ConfigType.TransmitHandler:
					return LocalizeSchema(GetResource("AdapterManagement.TransmitHandler.xsd"), resourceManager);
				case ConfigType.TransmitLocation:
					return LocalizeSchema(GetResource("AdapterManagement.TransmitLocation.xsd"), resourceManager);
				default:
					return null;
            }
        }
        public string[] GetServiceDescription(string[] wsdls) 
		{
            string[] result = new string[1];
            result[0] = GetResource("AdapterManagement.service1.wsdl");
            return result;
        }
        public string GetServiceOrganization(IPropertyBag endPointConfiguration,
                                             string NodeIdentifier) 
		{
            string result = GetResource("AdapterManagement.CategorySchema.xml");
            return result;
        }
        public Result GetSchema(string xsdLocation,
                                string xsdNamespace,
								out string xsdSchema) 
		{
            xsdSchema = null;
            return Result.Continue;
        }
        public string ValidateConfiguration(ConfigType configType,
            string xmlInstance) 
		{
            string validXml = String.Empty;
            switch (configType) 
			{
				case ConfigType.ReceiveHandler:
					validXml = xmlInstance; 
					break;
				case ConfigType.ReceiveLocation:
					validXml = ValidateReceiveLocation(xmlInstance); 
					break;
				case ConfigType.TransmitHandler:
					validXml = xmlInstance; 
					break;
				case ConfigType.TransmitLocation:
					validXml = ValidateTransmitLocation(xmlInstance); 
					break;
            }
            return validXml;
        }
        private string GetResource(string resource) 
		{
            string value = null;
            if (null != resource) 
			{
				Assembly assem = this.GetType().Assembly;
				Stream stream = assem.GetManifestResourceStream(resource);
				StreamReader reader = null;
                using (reader = new StreamReader(stream)) 
				{
                    value = reader.ReadToEnd();
                }
            }
            return value;
        }
		private string ValidateReceiveLocation(string xmlInstance) 
		{
			XmlDocument document = new XmlDocument();
			document.LoadXml(xmlInstance);
			StringBuilder builder = new StringBuilder();
			XmlNode virtualDirectory = document.SelectSingleNode("Config/virtualDirectory");
			XmlNode uri = document.SelectSingleNode("Config/uri");
			if (null == uri) 
			{
				uri = document.CreateElement("uri");
				document.DocumentElement.AppendChild(uri);
			}
			uri.InnerText = virtualDirectory.InnerText;
			return document.OuterXml;
		}
        private string ValidateTransmitLocation(string xmlInstance) 
		{
            XmlDocument document = new XmlDocument();
            document.LoadXml(xmlInstance);
            StringBuilder builder = new StringBuilder();
            XmlNode client = document.SelectSingleNode("Config/client");
            XmlNode appServerHost = document.SelectSingleNode("Config/appServerHost");
            XmlNode programId = document.SelectSingleNode("Config/programId");
            XmlNode destinationName = document.SelectSingleNode("Config/destinationName");
            if (client == null || client.InnerText == String.Empty)
                throw new ApplicationException("Transport properties validation failed.  Value for required adapter property \"Client Number\" is not specified.");
            if (appServerHost == null || appServerHost.InnerText == String.Empty ) 
				throw new ApplicationException("Transport properties validation failed.  Value for required adapter property \"SAP application Server Host\" is not specified.");
            if (programId == null || programId.InnerText == String.Empty)
                throw new ApplicationException("Transport properties validation failed.  Value for required adapter property \"Program Id\" is not specified.");
            if (destinationName == null || destinationName.InnerText == String.Empty)
                throw new ApplicationException("Transport properties validation failed.  Value for required adapter property \"Destination Name\" is not specified.");
            XmlNode uri = document.SelectSingleNode("Config/uri");
            if (null == uri) 
			{
                uri = document.CreateElement("uri");
                document.DocumentElement.AppendChild(uri);
            }
            uri.InnerText ="RFC.NET://" + appServerHost.InnerText + "/" + client.InnerText + "/" + destinationName.InnerText + "/" + programId.InnerText;
            return document.OuterXml;
        }
		protected string GetSchemaFromFile (string name)
		{
			RegistryKey bts30 = Registry.LocalMachine.OpenSubKey("SOFTWARE").OpenSubKey("Microsoft").OpenSubKey("BizTalk Server").OpenSubKey("3.0");
			string installPath = (string)bts30.GetValue("InstallPath");
			string productLanguage = (string)bts30.GetValue("ProductLanguage");
			string fullName = installPath + productLanguage + "\\" + name;
			StreamReader reader = new StreamReader(fullName);
			string schema = reader.ReadToEnd();
			return schema;
		}
	} 
}
