﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Schema;
using System.Collections;
using System.Data.Common;
using System.Data;
using System.Diagnostics;
using System.Threading;
using SAP.Middleware.Connector;
namespace BizTalk.Adapter.RFC.Core
{
    public class MessageDisassembly
    {
        private string prefix = "ns0";
        private XPathNavigator _navigator;
        private XmlNamespaceManager _spaceManager;
        private XmlSchema _schema;
        private AssemblySelector _selector;
        private string _namespace;
        private Hashtable _inparalist;
        private string _assemblyQualifiedName;
        private string _xmlType;
        private string _schemaType;
        private RfcDestination _rfcdest;
        private RfcRepository _rfcrep;
        private IRfcFunction _rfcfun = null;
        public MessageDisassembly()
        {
        }
        public MessageDisassembly(AssemblySelector selector, RfcDestination rfcdest)
        {
            this._selector = selector;
            this._schema = this._selector.GetSchema();
            this._rfcdest = rfcdest;
            this._rfcrep = _rfcdest.Repository;
            this._assemblyQualifiedName = selector.AssemblyQualifiedName;
            _inparalist = new Hashtable();
        }
        public string GetMessageType()
        {
            return this._xmlType;
        }
        public IRfcFunction Disassemble(XmlDocument message)
        {
            _navigator = message.CreateNavigator();
            _navigator.MoveToFirstChild();
            this._namespace = _navigator.NamespaceURI;
            _spaceManager = new XmlNamespaceManager(_navigator.NameTable);
            _spaceManager.AddNamespace(prefix, _namespace);
            this._rfcfun = this._rfcrep.CreateFunction(this._navigator.LocalName);
            _xmlType = string.Format("{1}#{0}", this._navigator.LocalName, this._namespace);
            _schemaType = string.Empty;
            XmlQualifiedName quaName = new XmlQualifiedName(this._navigator.LocalName, this._namespace);
            XmlSchemaObject schemaObject = this._schema.Elements[quaName];
            if (schemaObject == null)
                throw new NullReferenceException(
                    string.Format("This xml instance is not found the dependence schema {0}. ",
                    _xmlType));
            _schemaType = string.Format("{1}#{0}", this._navigator.Name, this._namespace);
            XmlSchemaElement element = schemaObject as XmlSchemaElement;
            Dictionary<string, object> row = null;
            ReadElement(element, 0, this._navigator, ref row);
            this.ExecuteCommand();
            return this._rfcfun;
        }
        public void ExecuteCommand()
        {
            this._rfcfun.Invoke(this._rfcdest);
        }
        private bool HasXmlSchemaComplexType(XmlSchemaElement element)
        {
            foreach (XmlSchemaElement item in ((XmlSchemaSequence)((XmlSchemaComplexType)element.ElementSchemaType).Particle).Items)
            {
                if (item.ElementSchemaType is XmlSchemaComplexType)
                {
                    return true;
                }
            }
            return false;
        }
        private void ReadElement(XmlSchemaElement element, int level, XPathNavigator navigator, ref Dictionary<string, object> dataRow, IRfcDataContainer rfcdatastructure = null, IRfcDataContainer prevrfcdatastructure = null, IRfcDataContainer prevrfctabledatastructure = null)
        {
            string tableName = string.Empty;
            string filter = string.Empty;
            string fieldName = string.Empty;
            object fieldValue = null;
            string fieldType = string.Empty;
            level++;
            string t = "\t";
            for (int l = 0; l < level; l++)
            {
                t += "\t";
            }
            XmlSchemaComplexType complexType = element.ElementSchemaType as XmlSchemaComplexType;
            XmlSchemaSequence sequence = complexType.Particle as XmlSchemaSequence;
            if (sequence == null)
            {
                throw new NullReferenceException(
                    string.Format("{0} Complex type of sequence specified in the definition of schema {1},{2}",
                    element.Name, _schemaType,this._assemblyQualifiedName));
            }
            foreach (XmlSchemaElement childElement in sequence.Items)
            {
                if (childElement.ElementSchemaType is XmlSchemaComplexType)
                {
                    tableName = childElement.Name;
                    var hasComplexNode = HasXmlSchemaComplexType(childElement);
                    if (childElement.MaxOccurs <= 1)
                    {
                        if (level == 1)
                        {
                            rfcdatastructure = this._rfcfun.GetStructure(tableName);
                        }
                        else
                        {
                            if (prevrfcdatastructure.GetType().Name == "RfcStructure")
                            {
                                rfcdatastructure = (prevrfcdatastructure as IRfcStructure).GetStructure(tableName);
                            }
                            else
                            {
                                rfcdatastructure = (prevrfcdatastructure as IRfcTable).GetStructure(tableName);
                            }
                        }
                        if (hasComplexNode)
                        {
                            prevrfcdatastructure = rfcdatastructure;
                        }
                    }
                    else
                    {
                        if (level == 1)
                        {
                            rfcdatastructure = this._rfcfun.GetTable(tableName);
                        }
                        else
                        {
                            if (prevrfctabledatastructure != null)
                                prevrfcdatastructure = prevrfctabledatastructure;
                            if (prevrfcdatastructure.GetType().Name == "RfcTable")
                            {
                                rfcdatastructure = (prevrfcdatastructure as IRfcTable).GetTable(tableName);
                            }
                            else
                            {
                                rfcdatastructure = (prevrfcdatastructure as IRfcStructure).GetTable(tableName);
                            }
                        }
                    }
                    if (childElement.MaxOccurs != 0)
                    {
                        XPathNodeIterator items = navigator.SelectChildren(childElement.Name, this._namespace);
                        if (childElement.MinOccurs > 0 && items.Count == 0)
                        {
                            throw new NullReferenceException(//childElement.Name,
                                string.Format("this xml node {0} must be required in the xsd definition.  {1},{2} ."
                                , childElement.Name
                                , this._xmlType
                                , this._assemblyQualifiedName
                                ));
                        }
                        while (items.MoveNext())
                        {
                            Dictionary<string, object> row = new Dictionary<string, object>();
                            if (rfcdatastructure.GetType().Name == "RfcTable")
                            {
                                var table = rfcdatastructure as IRfcTable;
                                table.Append();
                                ReadElement(childElement, level, items.Current.Clone(), ref row, rfcdatastructure, table, table);
                            }
                            else {
                                if (hasComplexNode)
                                {
                                    prevrfcdatastructure = rfcdatastructure;
                                }
                                ReadElement(childElement, level, items.Current.Clone(), ref row, rfcdatastructure, prevrfcdatastructure);
                            }
                            if (rfcdatastructure.GetType().Name == "RfcStructure")
                            {
                                var structure = rfcdatastructure as IRfcStructure;
                                foreach (var entry in row)
                                {
                                    structure.SetValue(entry.Key, entry.Value);
                                }
                            }
                            else
                            {
                                var table = rfcdatastructure as IRfcTable;
                                foreach (var entry in row)
                                {
                                    string val = entry.Value.ToString();
                                    string key = entry.Key;
                                    table.SetValue(key, entry.Value);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (childElement.MaxOccurs != 0)
                    {
                        fieldName = childElement.Name;
                        fieldType = childElement.SchemaTypeName.Name;
                        XPathNodeIterator item = navigator.SelectChildren(childElement.Name, this._namespace);
                        bool isexist = item.MoveNext();
                        if ((!isexist) && childElement.MinOccurs > 0)
                        {
                            throw new NullReferenceException(//childElement.Name,
                                string.Format("this xml element {0} must be required in the xsd definition.{1},{2}"
                                 , fieldName
                                , this._xmlType
                                 , this._assemblyQualifiedName
                                 ));
                        }
                        else
                        {
                            if (isexist && !string.IsNullOrEmpty(item.Current.Value))
                            {
                                switch (fieldType)
                                {
                                    case "base64Binary":
                                        fieldValue = Convert.FromBase64String(item.Current.Value);
                                        break;
                                    case "dateTime":
                                    case "date":
                                        fieldValue = item.Current.ValueAsDateTime;
                                        break;
                                    case "integer":
                                    case "int":
                                    case "unsignedInt":
                                        fieldValue = item.Current.ValueAsInt;
                                        break;
                                    case "long":
                                    case "unsignedLong":
                                        fieldValue = item.Current.ValueAsLong;
                                        break;
                                    case "double":
                                        fieldValue = item.Current.ValueAsDouble;
                                        break;
                                    case "float":
                                        fieldValue = item.Current.ValueAs(typeof(float));
                                        break;
                                    case "decimal":
                                        fieldValue = item.Current.ValueAs(typeof(decimal));
                                        break;
                                    default:
                                        fieldValue = item.Current.Value;
                                        break;
                                }
                            }
                            else
                                fieldValue = null;
                            if (fieldValue != null)
                            {
                                if (dataRow == null)
                                {
                                    this._rfcfun.SetValue(fieldName, fieldValue);
                                }
                                else
                                {
                                    dataRow.Add(fieldName, fieldValue);
                                }
                            }
                        }
                    }
                }
            }
        }
       
    }
}
